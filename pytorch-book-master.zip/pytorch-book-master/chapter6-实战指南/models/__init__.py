from .AlexNet import AlexNet
from .ResNet34 import ResNet34
# from torchvision.models import InceptinV3
# from torchvision.models import alexnet as AlexNet
