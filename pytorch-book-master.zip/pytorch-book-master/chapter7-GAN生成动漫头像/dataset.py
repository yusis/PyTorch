from torch import utils


class FaceDataset(utils.data.Dataset):
    pass
